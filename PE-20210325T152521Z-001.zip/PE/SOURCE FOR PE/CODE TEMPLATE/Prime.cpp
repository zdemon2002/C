//directive
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int IsPrime(int n) {//retuen 1 is n a prime number, otherwise return 0
	if(n < 2) return 0;
	if(n == 2) return 1;
	int i;
	for (i = 2; i <= sqrt(n); i++) {
		if(n % i == 0) return 0;
	}
	return 1;
}
int AfterPrime(int n) {//return a prime number after n
	int i; i = n + 1;
	while(1) {
		if (IsPrime(i)==1) break;
		else i++;
	}
	return i;
	
}
int BeforePrime(int n) {//return a prime number before n
	int i; i = n - 1;
	while(1) {
		if (IsPrime(i)==1) break;
		else i--;
	}
	return i;	
}

void PrintPrime(int k, int n) {
int i,x ; i = 0; x=n+1;
while(1){
			if(IsPrime(x)==1) 
					{	if(i==k) break; 
					else {i++; printf("%d   ",x) ; x++;}
				    }
		    else x++;
			
       }	
}
void swap(int& x, int& y) {
	int tg=x; x=y; y=tg;
	//printf("in swap, x  = %d, %y = %d\n",x,y);
}

void f1() {
	int a, b, c;
	printf("enter a:"); scanf("%d",&a);
	printf("enter b:"); scanf("%d",&b);
	printf("enter c:"); scanf("%d",&c);
	if (a>b) swap(a,b); else {if (a>c) swap(a,c);};
	if (b>c) swap(b,c);	
	printf("in main, a  = %d, b = %d, c = %d",a,b,c);
}
int main() {

}

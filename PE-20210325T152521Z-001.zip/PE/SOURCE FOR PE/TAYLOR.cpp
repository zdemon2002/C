//THAYCACAC
#include <stdio.h>
#include <math.h>

//HAM COS X = 1 - X^2/2! + X^4/4! -...+(-1)^N*X^2N/(2N)!
void funCos(double x, double &t, int n){
	for(int i=n; i>0; i--)
		t=1.0-t*x/(2*i-1)*x/(2*i);
	printf("%lf\n",t);
}
//HAM SIN X = X/1! - X^3/3! + X^5/5!-...+(-1)^N*X^(2N+1)/(2n+1)!
void funSin(double x, double &t, int n){
	for(int i=n; i>0; i--)
		t=1.0-t*x/(2*i)*x/(2*i+1);
	t*=x;
	printf("%lf\n",t);
}
//HAM E^X=1+X/1! + X^2/2! +...+ X^N/N!
void funpow(double x, double &t, int n){
	for(int i=n; i>0; i--)
		t=1+x*t/i;
	printf("%lf\n",t);
}
//HAM PI=4*(1-1/3+1/5-1/7+...+(-1)^N1/2N+1)
void funpi(double c){
	double pi=0;
	int i=0,d=1;
	while(1){
		if(fabs(1.0/(2*i+1))<=c)	break;
		i++;
	}
	for(int j=1; j<=(2*i+1); j+=2){
		pi+=d*1.0/j;
		d=-d;
	}
	printf("%lf",4*pi);
}

int main(){
	int n;
	double x,t,c;
//	printf("Enter x = ");
//	scanf("%lf",&x);
//	printf("Enter n = ");
//	scanf("%d",&n);
//	funCos(x,t,n);
//	funSin(x,t,n);
//	funpow(x, t, n);
//	printf("%lf",exp(x));
	
	printf("Enter c = ");
	scanf("%lf",&c);
	funpi(c);
}

#include<stdio.h>
#include<string.h>
int main()
{
	char sen[100];
	printf("Enter the sentence: ");
	gets(sen);
	printf("%s", sen);
	int cnt;
	if(sen[0] == ' ' || sen[strlen(sen) - 1] == ' ')
	{
		printf("\nThis sentence is not standard string");
		return 0;
	}
	for(int i = 1; i < strlen(sen) -1; i++)
	{
		if(sen[i] == ' ') cnt++;
		else cnt = 0;
		if(cnt == 2) 
		{
		printf("\nThis sentence is not standard string");
		return 0;
		}
	}
	printf("\nThis sentence is standard string");
}

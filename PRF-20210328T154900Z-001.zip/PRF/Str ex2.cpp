#include<stdio.h>
#include<string.h>
int main()
{
	char sen[100];
	printf("Enter the sentence: ");
	gets(sen);
	printf("%s", sen);
	int cnt1 = 0, cnt2 = 0;
	for(int i = 0; i < strlen(sen) ; i++)
	{
		if(sen[i] == ' ') cnt1++;
		if(sen[i] == 'a' || sen[i] == 'A' || sen[i] == 'i' || sen[i] == 'I' || sen[i] == 'e' || sen[i] == 'E' || sen[i] == 'o' || sen[i] == 'O' || sen[i] == 'u' || sen[i] == 'U' )
		cnt2++;
	}
	printf("\nVowels: %d", cnt2);
	printf("\nConsonants: %d",strlen(sen)-cnt1-cnt2);
}

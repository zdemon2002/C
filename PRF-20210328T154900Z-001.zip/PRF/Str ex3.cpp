#include<stdio.h>
#include<string.h>
int main()
{
	char sen[100];
	printf("Enter the sentence: ");
	gets(sen);
	printf("%s", sen);
	if(sen[0] >= 'a' && sen[0] <= 'z')
		sen[0]-= 32;
	for(int i = 0; i < strlen(sen); i++)
	{
		if(sen[i - 1] == ' ')
		{
			if(sen[i] >= 'a' && sen[i] <= 'z')
				sen[i]-= 32;
		}
	}
	printf("\n%s", sen);
}

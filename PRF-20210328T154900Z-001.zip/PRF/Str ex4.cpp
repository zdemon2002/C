#include<stdio.h>
#include<string.h>
int main()
{
    int n;
    printf("n= "); scanf("%d",&n);
    char s[n][100];
    int b[100], mx = -1e9, id;
    for(int i = 0; i < n; i++)
    {
    	scanf("%s", s[i]);
    	printf("%s\n", s[i] );
	}
    for(int i = 0; i < n; i++)
    {
        b[i] = strlen(s[i]);
        if(mx < b[i]){mx = b[i];id = i;}
    }
    printf("Max length: ");
    printf("%s\n", s[id]);
    printf("Strings have even length:");
    for(int i = 0; i < n; i++)
        if(b[i] % 2 == 0)printf("\n%s",s[i]); 
}

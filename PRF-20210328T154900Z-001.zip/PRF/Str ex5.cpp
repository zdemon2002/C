#include<stdio.h>
#include<string.h>
int main()
{
    int n, cnt;
    char s[100][100], a;
    printf("n= "); scanf("%d", &n);
    for(int i = 0; i < n; i++)
    {
    	scanf("%s", s[i]);
    	printf("%s\n", s[i]);
	}
    printf("Enter a character: ");
    fflush(stdin);
    scanf("%c", &a);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < strlen(s[i]);j++)
    {
        if(s[i][j] == a){cnt++;break;}
    }
    printf("%d",cnt);
}

#include<stdio.h>
#include<string.h>
int main()
{
	char sen[100];
	printf("Enter the sentence: ");
	gets(sen);
	printf("%s", sen);
	int cnt1 = 0, cnt2 = 0, cnt3 = 0;
	for(int i = 0; i < strlen(sen); i++)
	{
		if(sen[0] == ' ' && sen[strlen(sen) - 1] == ' ')
		{
			if(sen[i] == ' ') cnt1++;
		}
		else if(sen[0] == ' ' || sen[strlen(sen) - 1] == ' ')
		{
			if(sen[i] == ' ') cnt2++;
		}
		else if(sen[0] != ' ' && sen[strlen(sen) - 1] != ' ')
		{
			if(sen[i] == ' ') cnt3++;
		}
	}
	if(cnt1 != 0) printf("\nNumber of word: %d",cnt1 - 1);
	if(cnt2 != 0) printf("\nNumber of word: %d",cnt2);
	if(cnt3 != 0) printf("\nNumber of word: %d",cnt3 + 1);
	
}

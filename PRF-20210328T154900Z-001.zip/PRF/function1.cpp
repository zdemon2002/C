#include<stdio.h>
#include<math.h>
int Input(int *len, int *wid)
{
	printf("Length: "); scanf("%d", len);
	printf("Width: "); scanf("%d", wid);
}

int Area(int len, int wid)
{
	int area;
	area = len * wid;
	printf("%d", area);
}

int Perimeter(int len, int wid)
{
	int peri;
	peri = 2 * (len + wid);
	printf("%d", peri);
}

main()
{
	int len, wid;
	Input(&len,&wid);
	printf("Area: ");
	Area(len,wid);
	printf("\nPerimeter: ");
	Perimeter(len,wid);
}

#include<stdio.h>
#include<math.h>
void Input(int *a, int *b, int *c)
{
	printf("Enter 3 number: ");
	scanf("%d%d%d", a, b, c);
}
int Minmax(int a, int b, int c, int *ma)
{
	int min = a;
	int max = c;
	if(b < c && b < min) min = b;
	else if(b > c && c < min) min = c;
	if(max > b && max < a) max = a;
	else if(max > a && max < b) max = b;
	*ma = max;
	return min;
}
int Minus(int *min, int *max)
{
	return *max**max - *min**min;
}
void Divisors(int n)
{
	int i;
	for(i = 1; i <= sqrt((double)n); i++)
	{
		if(n % i == 0)
		{
			printf("%d ", i);
			if(i != n/i) printf("%d ",n/i);
		}
	}
}
void Output(int a, int b, int c)
{
	printf("\nDivisors of a: ");
	Divisors(a);
	printf("\nDivisors of b: ");
	Divisors(b);
	printf("\nDivisors of c: ");
	Divisors(c);
}
main()
{
	int a,b,c;
	Input(&a,&b,&c);
	int ma;
	int mi = Minmax(a,b,c,&ma);
	printf("\nMin: %d \t Max: %d", mi, ma);
	int s = Minus(&mi,&ma);
	printf("\nMinus: %d",s);
	Output(a,b,c);
	return 0;
}

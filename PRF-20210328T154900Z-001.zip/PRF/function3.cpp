#include<stdio.h>
void input(float *a){
	do{
		scanf("%f",a);
	}while(*a<0||*a>100);
}
void choice(float a){
	char choice;
	scanf("%c",&choice);
	fflush(stdin);
	switch(choice){
		case 'P':
			printf("%.1f",a);
			printf("%%");
			break;
		case 'D':
			printf("%.1f",a);
			break;
	}
}
int main(){
	float a;
	input(&a);
	fflush(stdin);
	choice(a);
}

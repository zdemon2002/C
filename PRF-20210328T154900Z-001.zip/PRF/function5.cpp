#include<stdio.h>
#include<math.h>
#include<stdlib.h>
void inputN(int *n)
{
	printf("\n input value:");
	scanf("%d",n);
}
void inputArray(int n, int a[]) 
{
	int i;
	for(i = 0; i < n; i++)
	{
		printf("a[%d]=",i);
		scanf("%d",&a[i]); 
	}
}
void outputArray(int n, int a[])
{
	int i; // local variable
	for(i = 0; i < n; i++)
	{
		printf("\n a[%d]=%d",i,a[i]);
	}
}
int Minmax(int a[], int n, int *max)
{
	int min = 1e9;
	*max = -1e9;
	int i;
	for(i = 0; i < n; i++)
	{
		if(a[i] > 0 && a[i] < min) min = a[i];
		else if(a[i] < 0 && a[i] > *max) *max = a[i];	
	}
	return min;
}
int CntsquareN(int a[], int n)
{
	int b,i, cnt=0;
	for(int i=0;i<n;i++){
		b = sqrt(a[i]);
	if(b * b == a[i]){
		cnt++;
		//if(cnt == 0) printf("No square number in the array");}
	}
//	if(cnt == 0) printf("No square number in the array");
//	printf("\n%d", cnt);
}
if(cnt == 0) printf("\nNo square number in the array\n");
else printf("\nSquare number in the array: %d", cnt);
}
int checkSNT(int k)
{
	int i;
	if(k < 2) return 0;
	for(i = 2; i <= sqrt(k); i++)
	{
		if(k % i == 0) return 0;
	} return 1; //ket thuc for nghia la k khong chia het cho i --> k la SNT
}
int TotalSNT(int a[], int n)
{
	int i, sum=0;
	for(i = 0; i < n; i++)
	{
		if(checkSNT(a[i]) == 1)
		sum+= a[i];
	}
	printf("%d", sum);
}
void DescendingSort(int a[], int n)
{
	int i,j;
	for (i=0;i<n-1;i++)  
    {   
        for (j = i+1; j < n; j++)  
        if (a[j] > a[i]) 
		{  
        int tg=a[j]; 
		a[j]=a[i]; 
		a[i]=tg;}
    }  
	for(i=0;i<n;i++) printf("%d ",a[i]);
}

int main()
{
	int n,c = 0, a[100];
	while(c < 8){
		printf("\n1. Enter the size and integer array from the keyboard.\n2. Display array to the screen.\n3. Find and display to the screen min positive and max negative number.\n4. Count square number in the array. Display result to the screen.\n5. Calculate and display to the screen total prime number in the array.\n6. Sort array descending and display it after sorting.\n7. Exit from program\n");	
	printf("\nEnter your choice please:"); scanf("%d",&c);
	if(c == 1) 
	{
		inputN(&n);
		inputArray(n,a);
	}
	if(c == 2) outputArray(n,a);
	if(c == 3) 
	{
	int max;
	int min = Minmax(a,n,&max);
	printf("\nMin: %d \t Max: %d", min, max);
	}
	if(c == 4) 
	{
		//printf("\nSquare number in the array");
		CntsquareN(a,n);
	}
	if(c == 5) 
	{
		printf("\nTotal prime number in the array: ");
		TotalSNT(a,n);
	}
	if(c == 6) DescendingSort(a,n);
	if(c == 7) exit(0);}
}
//#include<stdio.h>
//#include<stdlib.h>
//#include<math.h>
//void one(int *n, int a[])
//{
//	printf("Enter n: "); scanf("%d",n);
//	int i;
//	for(i=0;i<*n;i++)
//	{
//		printf("a[%d]=",i);
//		scanf("%d",&a[i]);
//	}
//}
//void two(int *n, int a[])
//{
//	int i;
//	for(int i=0;i<*n;i++)
//	{
//		printf("a[%d]=%d\n",i,a[i]);
//	}
//}
//int three(int *n,int a[], int *max)
//{
//	int i;
//	int min=32767;
//	*max=-32768;
//	for(i=0;i<*n;i++)
//	{
//		if(a[i]>0 && a[i]<min) min=a[i];
//		else if(a[i]<0 && a[i]>*max) *max=a[i];
//	}
//	return min;
//}
//int four(int *n, int a[])
//{
//	int i, dem=0;
//	for(i=0;i<*n;i++)
//	{
//		int c=(int)sqrt(a[i]);
//		if(sqrt(a[i])==c) dem++;
//	}
//	return dem;
//}
//bool sangnt(int n)
//{
//	int i,j;
//    bool check[n+1];   
//	for( i=2;i<=n;i++)
//	{
//		 check[i]=1; 
//	} 
//	for(i=2;i<=n;i++)
//	{
//		if(check[i]==1);
//		{
//			for( j=2*i;j<=n;j+=i)
//			{
//				check[j]=0; 
//			} 
//		} 
//	 }
//	 if (check[n]==1) return 1;
//	 else return 0;
// } 
//int five(int *n,int a[])
// {
// 	int i;
// 	int dem=0;
// 	int s=0;
// 	for(i=0;i<*n;i++)
// 	{
// 		if(sangnt(a[i])==1) 
//		 {
//		    dem++;
//		 	s+=a[i];
//		 }
//	}
//	if(dem==0) printf("no prime number ");
//	return s;
// }
// void six(int *n, int a[])
// {
// 	for(int i=0;i<*n-1;i++) 
// 	{
// 		for(int j=i+1;j<*n;j++) 
// 		{
// 			if(a[i]<a[j]) 
// 			{
// 				int temp=a[i];
// 				a[i]=a[j];
// 				a[j]=temp;
//			 }
//		 }
//	 }
//	 printf("Array after sorting: ");
//	 for(int i=0;i<*n;i++)
//	 {
//	 	printf("%d ",a[i]); 
//	  } 
//  } 
//int main()
//{
//	int x;
//	int n, a[1000];
//	int min,max;
//	while(1)
//	{
//	printf("\n1. Enter the size and integer array from the keyboard.\n2. Display array to the screen.\n3. Find and display to the screen min positive and max negative number.\n4. Count square number in the array. Display result to the screen.\n5. Calculate and display to the screen total prime number in the array.\n6. Sort array descending and display it after sorting.\n7. Exit from program\n\n");	
//		scanf("%d",&x);
//		switch(x){
//			case 1: {
//				one(&n,a);
//				break;
//			}
//			case 2:{
//				two(&n,a);
//				break;
//			}
//			case 3:{
//				printf("\nMin positive is ");
//				min=three(&n,a,&max);
//				printf("%d",min);
//				printf("\nMax negetive is ");
//				printf("%d",max);
//				break;
//			}
//			case 4:{
//				printf("Number of square number in array is: %d",four(&n,a));
//				break;
//			}
//			case 5:{
//				printf("%d",five(&n,a));
//				break;
//			}
//			case 6:{
//				six(&n,a);
//				break;
//			}
//			case 7: exit(0);
//		}
//	}
//}
